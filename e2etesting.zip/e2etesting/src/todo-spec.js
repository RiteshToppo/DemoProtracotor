describe('Launch Movie website', function() {
 
  beforeEach(function() {
    browser.get('http://3.212.88.170:4000/');

  });
 
  it('Search for Selected movies' ,function() {


    element(by.xpath('//input[@id="searchField"]')).sendKeys('Africa Screams');
    element(by.xpath('//button[contains(@class,"btn-outline-primary")]')).click();

    var todoList = element(by.xpath('//span[@class="text-secondary"]'));
   
   expect(todoList.getText()).toEqual('1 Movies');
       
  	});
  
  it('Search for Contitinent' , function() {
  

    element(by.xpath('//i[@class="fas fa-list mr-2"]')).click();
    element(by.xpath('//li[contains(@class,"list-group-item text-primary")][1]')).click();
    var todoList = element(by.xpath('//span[@class="text-secondary"]'));
    browser.driver.sleep(1000);
    browser.waitForAngular();
   expect(todoList.getText()).toEqual('7 Continents');
     let value = element.all(by.xpath('//table/thead/tr/th')).reduce(function(acc, elem) { 
  return elem.getText().then(function(text) { 
     return acc + text + ' '; 
    }); 
}, ''); 
expect(value).toEqual('N° Pos Id Wiki Name Code Area Population Countries French Name ');
  });
  
  
  it('Search for Countries' , function() {

     element(by.xpath('//i[@class="fas fa-list mr-2"]')).click();
    element(by.xpath('//li[contains(@class,"list-group-item text-primary")][2]')).click();
     browser.driver.sleep(1000);
    browser.waitForAngular();
    var todoList = element(by.xpath('//span[@class="text-secondary"]'));
    browser.driver.sleep(1000);
    browser.waitForAngular();
     expect(todoList.getText()).toEqual('251 Countries');
   let value = element.all(by.xpath('//table/thead/tr/th')).reduce(function(acc, elem) { 
  return elem.getText().then(function(text) { 
     return acc + text + ' '; 
    }); 
}, ''); 
  expect(value).toEqual('N° Pos Id Wiki Name Flag Iso2 Iso3 Iso Continent Code ');
  });
  
  
  it('Search for Cities' , function() {
   

    element(by.xpath('//i[@class="fas fa-list mr-2"]')).click();
    element(by.xpath('//li[contains(@class,"list-group-item text-primary")][3]')).click();
    browser.driver.sleep(1000);
    browser.waitForAngular();
    var todoList = element(by.xpath('//span[@class="text-secondary"]'));
    browser.driver.sleep(1000);
    browser.waitForAngular();
   
   expect(todoList.getText()).toEqual('7 Cities');
  let value = element.all(by.xpath('//table/thead/tr/th')).reduce(function(acc, elem) { 
  return elem.getText().then(function(text) { 
     return acc + text + ' '; 
    }); 
}, ''); 
expect(value).toEqual('N° Pos Id Wiki Name Capital Country Flag Continent Code ');
  });
  
    it('Search for Movies' , function() {
   

    element(by.xpath('//i[@class="fas fa-list mr-2"]')).click();
    element(by.xpath('//li[contains(@class,"list-group-item text-primary")][4]')).click();
    var todoList = element(by.xpath('//span[@class="text-secondary"]'));
    browser.driver.sleep(1000);
    browser.waitForAngular();
   
   
   expect(todoList.getText()).toEqual('26 Movies');
  let value = element.all(by.xpath('//table/thead/tr/th')).reduce(function(acc, elem) { 
  return elem.getText().then(function(text) { 
     return acc + text + ' '; 
    }); 
}, ''); 
expect(value).toEqual('N° Pos Id Wiki Img Name Date ');
  });
  
});

